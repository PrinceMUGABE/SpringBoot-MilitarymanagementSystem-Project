package com.example.military;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MilitarymanagementsystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(MilitarymanagementsystemApplication.class, args);
    }

}
